using AirTransportApi.Data;
using AirTransportApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AirTransportApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AirportsController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var data = await db.Set<Airport>()
            .Include(a => a.Улица)
            .ThenInclude(u => u!.Город)
            .ThenInclude(g => g!.Страна)
            .Select(a => new
            {
                a.id,
                a.Название,
                Улица = a.Улица!.Название,
                Город = a.Улица.Город!.Название,
                Страна = a.Улица.Город.Страна!.Название,
            })
            .ToListAsync();

        return Ok(data);
    }
}
