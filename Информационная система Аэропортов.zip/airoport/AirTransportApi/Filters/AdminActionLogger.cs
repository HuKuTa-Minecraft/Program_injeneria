using Microsoft.AspNetCore.Mvc.Filters;

namespace AirTransportApi.Filters;

// Пишет в лог любые POST/DELETE действия администратора
public class AdminActionLogger(ILogger<AdminActionLogger> logger) : IActionFilter
{
    public void OnActionExecuting(ActionExecutingContext ctx) { }

    public void OnActionExecuted(ActionExecutedContext ctx)
    {
        if (ctx.HttpContext.Session.GetString("IsAdmin") == "true")
        {
            var user = ctx.HttpContext.Session.GetString("AdminUser") ?? "unknown";
            var method = ctx.HttpContext.Request.Method;
            var path = ctx.HttpContext.Request.Path;
            logger.LogInformation("ADMIN {User} -> {Method} {Path}", user, method, path);
        }
    }
}
