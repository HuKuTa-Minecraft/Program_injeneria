import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  Typography,
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { useEffect, useState, useContext } from "react";
import api from "../api/axios";
import { AuthContext } from "../context/AuthContext";

export default function Schedule() {
  const { role } = useContext(AuthContext);

  const [rows, setRows] = useState([]);
  const [mans, setMans] = useState([]);
  const [open, setOpen] = useState(false);
  const [dataTimeUp, setDataTimeUp] = useState("");
  const [dataTimeDown, setDataTimeDown] = useState("");
  const [manId, setManId] = useState("");
  
  useEffect(() => {
    (async () => {
      const response = await api.get("/schedules");
      console.log("Что пришло с сервера:", response.data); // 👈 это ключ!
      setRows(response.data);
      setMans((await api.get("/routes")).data);
      
    })();
  }, []);

  //useEffect(() => {
  //  (async () => {
  //    setRows((await api.get("/schedules")).data);
  //    setMans((await api.get("/routes")).data);
  //  })();
  //}, []);

  const refresh = async () => setRows((await api.get("/schedules")).data);

  const add = async () => {
    await api.post("/schedules", {
      вылет: dataTimeUp,
      прилёт: dataTimeDown,
      RtId: manId,
    });
    await refresh();
    setOpen(false);
  };

  const del = async (id) => {
    if (!confirm("Удалить?")) return;
    await api.delete(`/schedules/${id}`);
    await refresh();
  };

  const cols = [
    { field: "id", headerName: "ID", width: 70 },
    { field: "вылет", headerName: "Дата и Время вылета", flex: 1, valueFormatter: (params) => params.value ? new Date(params.value).toLocaleString("ru-RU") : "", },
    { field: "прилёт", headerName: "Дата и Время посадки", flex: 1, valueFormatter: (params) => params.value ? new Date(params.value).toLocaleString("ru-RU") : "", },
    { field: "rtId", headerName: "ID маршрута", width: 120 },
    role === "Admin" && {
      field: "",
      width: 90,
      renderCell: (p) => (
        <Button color="error" onClick={() => del(p.row.id)}>
          X
        </Button>
      ),
    },
  ].filter(Boolean);

  return (
    <Box>
      <Typography variant="h4" mb={2}>
        Рейсы
      </Typography>
      {role === "Admin" && (
        <Button variant="contained" onClick={() => setOpen(true)}>
          Добавить
        </Button>
      )}
      <div style={{ height: 400, marginTop: 16 }}>
        <DataGrid rows={rows} columns={cols} disableRowSelectionOnClick />
      </div>

      {/* диалог добавления */}
      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogTitle>Новый рейс</DialogTitle>
        <DialogContent
          sx={{ display: "flex", flexDirection: "column", gap: 2, mt: 1 }}
        >
          <TextField
          label="Дата и время вылета"
          type="datetime-local"
          value={dataTimeUp}
          onChange={(e) => setDataTimeUp(e.target.value)}
          InputLabelProps={{ shrink: true }}
          />
          <TextField
          label="Дата и время посадки"
          type="datetime-local"
          value={dataTimeDown}
          onChange={(e) => setDataTimeDown(e.target.value)}
          InputLabelProps={{ shrink: true }}
          />
          <TextField
            select
            label="ID маршрута"
            value={manId}
            onChange={(e) => setManId(e.target.value)}
          >
            {mans.map((m) => (
              <MenuItem key={m.id} value={m.id}>
                {m.id}
              </MenuItem>
            ))}
          </TextField>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Отмена</Button>
          <Button onClick={add} variant="contained">
            Сохранить
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
