using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AirTransportApi.Models;

[Table("Маршрут")]
public class Rt
{
    [Key]
    public int id { get; set; }

    [Column("Расстояние_id")]
    public int РасстояниеId { get; set; }

    [Column("Самолет_id")]
    public int СамолетId { get; set; }

    [Column("Перевозчик_id")]
    public int ПеревозчикId { get; set; }

    public Distance? Расстояние { get; set; }
    public Airplane? Самолет { get; set; }
    public Carrier? Перевозчик { get; set; }

    public ICollection<Schedule> Расписания { get; set; } = new List<Schedule>();
    public ICollection<Tariff> Тарифы { get; set; } = new List<Tariff>();
}
