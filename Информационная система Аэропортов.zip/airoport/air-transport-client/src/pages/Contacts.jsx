import { Typography } from "@mui/material";
export default () => (
  <>
    <Typography variant="h4" mb={2}>
      Контакты
    </Typography>
    <Typography>+1 (555) 000-0000 — Support</Typography>
    <Typography>info@airtransport.fake</Typography>
  </>
);
