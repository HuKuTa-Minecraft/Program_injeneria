import { Box, Typography, Link } from "@mui/material";

export default () => (
  <Box
    component="footer"
    sx={{ p: 2, textAlign: "center", bgcolor: "grey.200" }}
  >
    <Typography variant="body2">
      © 2025 AirTransport | <Link href="/contacts">Контакты</Link> | Политика
    </Typography>
  </Box>
);
