using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AirTransportApi.Models;

[Table("Класс")]
public class FlightClass
{
    [Key]
    public int id { get; set; }

    [Column("Название")]
    public string Название { get; set; } = null!;

    [Column("Приоритет")]
    public int Приоритет { get; set; }

    public ICollection<Tariff> Тарифы { get; set; } = new List<Tariff>();
}
