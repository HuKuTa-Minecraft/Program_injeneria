import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:5111/api",
  withCredentials: true,
});

api.interceptors.response.use(
  (r) => r,
  (err) => {
    if (err.response?.status === 401) localStorage.removeItem("role");
    return Promise.reject(err);
  }
);

export default api;
