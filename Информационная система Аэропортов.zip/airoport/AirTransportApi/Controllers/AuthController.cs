using AirTransportApi.Data;
using AirTransportApi.Filters;
using AirTransportApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AirTransportApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController(AppDbContext db) : ControllerBase
{
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginDto dto)
    {
        var admin = await db.Admins.SingleOrDefaultAsync(a =>
            a.Username == dto.Username && a.Password == dto.Password
        );

        if (admin is null)
            return Unauthorized("Неверный логин или пароль");

        HttpContext.Session.SetString("IsAdmin", "true");
        HttpContext.Session.SetString("AdminUser", admin.Username);
        return Ok();
    }

    [HttpPost("logout")]
    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return Ok();
    }

    [HttpPost("register")]
    [RequireAdmin]
    public async Task<IActionResult> Register([FromBody] RegisterDto dto)
    {
        if (await db.Admins.AnyAsync(a => a.Username == dto.Username))
            return BadRequest("Пользователь уже существует");

        var entity = new Admin { Username = dto.Username, Password = dto.Password };
        db.Admins.Add(entity);
        await db.SaveChangesAsync();
        return Ok();
    }

    public record LoginDto(string Username, string Password);

    public record RegisterDto(string Username, string Password);
}
