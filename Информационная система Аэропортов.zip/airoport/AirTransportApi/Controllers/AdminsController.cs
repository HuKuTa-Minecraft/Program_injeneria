using AirTransportApi.Data;
using AirTransportApi.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AirTransportApi.Controllers;

[ApiController]
[Route("api/[controller]")]
[RequireAdmin]
public class AdminsController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Get() =>
        Ok(
            await db
                .Admins.Select(a => new
                {
                    a.id,
                    a.Username,
                    a.CreatedAt,
                })
                .ToListAsync()
        );

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var adm = await db.Admins.FindAsync(id);
        if (adm is null)
            return NotFound();
        db.Admins.Remove(adm);
        await db.SaveChangesAsync();
        return NoContent();
    }
}
