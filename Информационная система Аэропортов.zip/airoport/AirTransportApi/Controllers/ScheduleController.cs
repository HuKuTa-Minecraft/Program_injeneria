using AirTransportApi.Data;
using AirTransportApi.Filters;
using AirTransportApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AirTransportApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SchedulesController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var list = await db
            .Schedules.Include(a => a.Rt)
            .Select(a => new {
                id = a.id,
                вылет = a.Вылет,
                прилёт = a.Прилёт,
                rtId = a.RtId
                })
            .ToListAsync();
        return Ok(list);
    }

    [HttpPost]
    [RequireAdmin]
    public async Task<IActionResult> Add([FromBody] Schedule a)
    {
        db.Schedules.Add(a);
        await db.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { a.id }, a);
    }

    [HttpDelete("{id:int}")]
    [RequireAdmin]
    public async Task<IActionResult> Delete(int id)
    {
        var entity = await db.Schedules.FindAsync(id);
        if (entity is null)
            return NotFound();
        db.Schedules.Remove(entity);
        await db.SaveChangesAsync();
        return NoContent();
    }
}
