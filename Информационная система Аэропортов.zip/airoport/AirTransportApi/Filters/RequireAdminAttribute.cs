using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace AirTransportApi.Filters;

// Проверяет, что в сессии установлен флаг IsAdmin=true
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public class RequireAdminAttribute : Attribute, IAsyncActionFilter
{
    public async Task OnActionExecutionAsync(
        ActionExecutingContext ctx,
        ActionExecutionDelegate next
    )
    {
        var isAdmin = ctx.HttpContext.Session.GetString("IsAdmin");
        if (isAdmin != "true")
        {
            ctx.Result = new UnauthorizedResult();
            return;
        }
        await next();
    }
}
