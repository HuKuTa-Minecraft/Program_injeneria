using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AirTransportApi.Models;

[Table("Самолет")]
public class Airplane
{
    [Key]
    public int id { get; set; }

    [Column("Модель")]
    public string Модель { get; set; } = null!;

    [Column("Производитель_id")]
    public int ПроизводительId { get; set; }

    [Column("Скорость полета")]
    public int СкоростьПолёта { get; set; }

    public Manufacturer? Производитель { get; set; }

    public ICollection<AirplaneCarrier> Перевозчики { get; set; } = new List<AirplaneCarrier>();
    public ICollection<Rt> Маршруты { get; set; } = new List<Rt>();
}
