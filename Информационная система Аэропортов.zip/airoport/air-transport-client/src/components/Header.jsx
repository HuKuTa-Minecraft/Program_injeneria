import { AppBar, Toolbar, Button } from "@mui/material";
import { NavLink, useNavigate } from "react-router-dom";
import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import AirplanemodeActiveIcon from "@mui/icons-material/AirplanemodeActive";

const links = [
  { to: "/", label: "Главная" },
  { to: "/airplanes", label: "Самолёты" },
  { to: "/passengers", label: "Пассажирам" },
  { to: "/schedules", label: "Расписание" },
  { to: "/routes", label: "Маршруты" },
  { to: "/contacts", label: "Контакты" },
];
const adminLinks = [{ to: "/register", label: "Регистрация" }];

export default function Header() {
  const { role, logout } = useContext(AuthContext);
  const nav = useNavigate();

  return (
    <AppBar position="static">
      <Toolbar>
        <AirplanemodeActiveIcon sx={{ mr: 2 }} />
        {links.map((l) => (
          <Button key={l.to} color="inherit" component={NavLink} to={l.to}>
            {l.label}
          </Button>
        ))}
        {role === "Admin" &&
          adminLinks.map((l) => (
            <Button key={l.to} color="inherit" component={NavLink} to={l.to}>
              {l.label}
            </Button>
          ))}
        <div style={{ flexGrow: 1 }} />
        {role === "Guest" ? (
          <Button color="inherit" component={NavLink} to="/login">
            Вход
          </Button>
        ) : (
          <Button
            color="inherit"
            onClick={() => {
              logout();
              nav("/");
            }}
          >
            Выход
          </Button>
        )}
      </Toolbar>
    </AppBar>
  );
}
