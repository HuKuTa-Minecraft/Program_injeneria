using AirTransportApi.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[ApiController]
[Route("api/[controller]")]
public class DistancesController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List()
    {
        var list = await db
            .Distances.Include(d => d.АэропортВылета)
            .Include(d => d.АэропортПрилёта)
            .Select(d => new
            {
                d.id,
                аэропортВылета = d.АэропортВылета!.Название,
                аэропортПрилёта = d.АэропортПрилёта!.Название,
                d.Путь,
            })
            .ToListAsync();

        return Ok(list);
    }
}
