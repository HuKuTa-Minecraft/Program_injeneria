using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AirTransportApi.Models;

[Table("Расписание")]
public class Schedule
{
    [Key]
    public int id { get; set; }

    [Column("Дата и Время вылета")]
    public DateTime Вылет { get; set; }

    [Column("Дата и Время прилета")]
    public DateTime Прилёт { get; set; }

    [Column("Маршрут_id")]
    public int RtId { get; set; }

    public Rt? Rt { get; set; }
}
