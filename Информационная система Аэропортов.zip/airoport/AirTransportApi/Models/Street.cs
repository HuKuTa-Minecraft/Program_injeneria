using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AirTransportApi.Models;

[Table("Улица")]
public class Street
{
    [Key]
    public int id { get; set; }

    [Column("Название")]
    public string Название { get; set; } = null!;

    [Column("Город_id")]
    public int ГородId { get; set; }
    public City? Город { get; set; }

    public ICollection<Airport> Аэропорты { get; set; } = new List<Airport>();
}
