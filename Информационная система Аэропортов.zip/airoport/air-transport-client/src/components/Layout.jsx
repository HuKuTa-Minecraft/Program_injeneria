import { Outlet } from "react-router-dom";
import Header from "./Header";
import Footer from "./Footer";

export default function Layout() {
  return (
    <>
      <Header />
      <main style={{ padding: "24px", minHeight: "calc(100vh - 128px)" }}>
        <Outlet />
      </main>
      <Footer />
    </>
  );
}
