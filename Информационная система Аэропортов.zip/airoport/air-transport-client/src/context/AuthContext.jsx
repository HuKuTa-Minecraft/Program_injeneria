import { createContext, useState, useEffect } from "react";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [role, setRole] = useState("Guest"); // "Guest" | "Admin"

  /* читаем флажок при загрузке */
  useEffect(() => {
    if (localStorage.getItem("role") === "Admin") setRole("Admin");
  }, []);

  const login = () => {
    localStorage.setItem("role", "Admin");
    setRole("Admin");
  };
  const logout = () => {
    localStorage.removeItem("role");
    setRole("Guest");
  };

  return (
    <AuthContext.Provider value={{ role, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
