import { Typography } from "@mui/material";
export default () => (
  <Typography variant="h3" align="center">
    Добро пожаловать в AirTransport !
  </Typography>
);
