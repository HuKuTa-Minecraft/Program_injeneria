using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AirTransportApi.Models;

[Table("Расстояние")]
public class Distance
{
    [Key]
    public int id { get; set; }

    [Column("Аэрапорт вылет_id")]
    public int АэропортВылетаId { get; set; }

    [Column("Аэрапорт прилет_id")]
    public int АэропортПрилётаId { get; set; }

    [Column("Путь")]
    public int Путь { get; set; }

    [ForeignKey(nameof(АэропортВылетаId))]
    public Airport? АэропортВылета { get; set; }

    [ForeignKey(nameof(АэропортПрилётаId))]
    public Airport? АэропортПрилёта { get; set; }

    public ICollection<Rt> Маршруты { get; set; } = new List<Rt>();
}
