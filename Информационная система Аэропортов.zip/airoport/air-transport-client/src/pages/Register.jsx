import { Paper, TextField, Button, Box, Typography } from "@mui/material";
import { useState } from "react";
import api from "../api/axios";

export default function Register() {
  const [u, setU] = useState(""),
    [p, setP] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    try {
      await api.post("/auth/register", { username: u, password: p });
      alert("Администратор создан");
      setU("");
      setP("");
    } catch (err) {
      alert(err.response?.data ?? "Ошибка");
    }
  };

  return (
    <Paper sx={{ maxWidth: 400, mx: "auto", mt: 8, p: 3 }}>
      <Typography variant="h5" align="center" mb={2}>
        Регистрация администратора
      </Typography>
      <Box
        component="form"
        onSubmit={submit}
        display="flex"
        flexDirection="column"
        gap={2}
      >
        <TextField
          label="Логин"
          value={u}
          onChange={(e) => setU(e.target.value)}
          required
        />
        <TextField
          label="Пароль"
          type="password"
          value={p}
          onChange={(e) => setP(e.target.value)}
          required
        />
        <Button type="submit" variant="contained">
          Добавить
        </Button>
      </Box>
    </Paper>
  );
}
