import { DataGrid } from "@mui/x-data-grid";
import { Box, Typography } from "@mui/material";
import { useEffect, useState } from "react";
import api from "../api/axios";

export default function Passengers() {
  const [rows, setRows] = useState([]);

  useEffect(() => {
    (async () => setRows((await api.get("/airports")).data))();
  }, []);

  const cols = [
    { field: "id", headerName: "ID", width: 70 },
    { field: "название", headerName: "Аэропорт", flex: 1 },
    { field: "улица", headerName: "Улица", flex: 1 },
    { field: "город", headerName: "Город", flex: 1 },
    { field: "страна", headerName: "Страна", flex: 1 },
  ];

  return (
    <Box>
      <Typography variant="h4" mb={2}>
        Информация для пассажиров
      </Typography>
      <div style={{ height: 400 }}>
        <DataGrid rows={rows} columns={cols} />
      </div>
    </Box>
  );
}
