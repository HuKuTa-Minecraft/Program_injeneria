﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace AirTransportApi.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Администратор",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    username = table.Column<string>(type: "text", nullable: false),
                    password = table.Column<string>(type: "text", nullable: false),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Администратор", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Класс",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Название = table.Column<string>(type: "text", nullable: false),
                    Приоритет = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Класс", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Перевозчик",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Название = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Перевозчик", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Производитель",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Название = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Производитель", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Страна",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Название = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Страна", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Самолет",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Модель = table.Column<string>(type: "text", nullable: false),
                    Производитель_id = table.Column<int>(type: "integer", nullable: false),
                    Скоростьполета = table.Column<int>(name: "Скорость полета", type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Самолет", x => x.id);
                    table.ForeignKey(
                        name: "FK_Самолет_Производитель_Производитель_id",
                        column: x => x.Производитель_id,
                        principalTable: "Производитель",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Город",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Название = table.Column<string>(type: "text", nullable: false),
                    Страна_id = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Город", x => x.id);
                    table.ForeignKey(
                        name: "FK_Город_Страна_Страна_id",
                        column: x => x.Страна_id,
                        principalTable: "Страна",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Самолет и перевозчик",
                columns: table => new
                {
                    Самолет_id = table.Column<int>(type: "integer", nullable: false),
                    Перевозчик_id = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Самолет и перевозчик", x => new { x.Самолет_id, x.Перевозчик_id });
                    table.ForeignKey(
                        name: "FK_Самолет и перевозчик_Перевозчик_Перевозчик_id",
                        column: x => x.Перевозчик_id,
                        principalTable: "Перевозчик",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Самолет и перевозчик_Самолет_Самолет_id",
                        column: x => x.Самолет_id,
                        principalTable: "Самолет",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Улица",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Название = table.Column<string>(type: "text", nullable: false),
                    Город_id = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Улица", x => x.id);
                    table.ForeignKey(
                        name: "FK_Улица_Город_Город_id",
                        column: x => x.Город_id,
                        principalTable: "Город",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Аэрапорт",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Название = table.Column<string>(type: "text", nullable: false),
                    Улица_id = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Аэрапорт", x => x.id);
                    table.ForeignKey(
                        name: "FK_Аэрапорт_Улица_Улица_id",
                        column: x => x.Улица_id,
                        principalTable: "Улица",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Расстояние",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Аэрапортвылет_id = table.Column<int>(name: "Аэрапорт вылет_id", type: "integer", nullable: false),
                    Аэрапортприлет_id = table.Column<int>(name: "Аэрапорт прилет_id", type: "integer", nullable: false),
                    Путь = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Расстояние", x => x.id);
                    table.ForeignKey(
                        name: "FK_Расстояние_Аэрапорт_Аэрапорт вылет_id",
                        column: x => x.Аэрапортвылет_id,
                        principalTable: "Аэрапорт",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Расстояние_Аэрапорт_Аэрапорт прилет_id",
                        column: x => x.Аэрапортприлет_id,
                        principalTable: "Аэрапорт",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Маршрут",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Расстояние_id = table.Column<int>(type: "integer", nullable: false),
                    Самолет_id = table.Column<int>(type: "integer", nullable: false),
                    Перевозчик_id = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Маршрут", x => x.id);
                    table.ForeignKey(
                        name: "FK_Маршрут_Перевозчик_Перевозчик_id",
                        column: x => x.Перевозчик_id,
                        principalTable: "Перевозчик",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Маршрут_Расстояние_Расстояние_id",
                        column: x => x.Расстояние_id,
                        principalTable: "Расстояние",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Маршрут_Самолет_Самолет_id",
                        column: x => x.Самолет_id,
                        principalTable: "Самолет",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Расписание",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    ДатаиВремявылета = table.Column<DateTime>(name: "Дата и Время вылета", type: "timestamp with time zone", nullable: false),
                    ДатаиВремяприлета = table.Column<DateTime>(name: "Дата и Время прилета", type: "timestamp with time zone", nullable: false),
                    Маршрут_id = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Расписание", x => x.id);
                    table.ForeignKey(
                        name: "FK_Расписание_Маршрут_Маршрут_id",
                        column: x => x.Маршрут_id,
                        principalTable: "Маршрут",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Тариф",
                columns: table => new
                {
                    id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Название = table.Column<string>(type: "text", nullable: false),
                    Класс_id = table.Column<int>(type: "integer", nullable: false),
                    Маршрут_id = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Тариф", x => x.id);
                    table.ForeignKey(
                        name: "FK_Тариф_Класс_Класс_id",
                        column: x => x.Класс_id,
                        principalTable: "Класс",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Тариф_Маршрут_Маршрут_id",
                        column: x => x.Маршрут_id,
                        principalTable: "Маршрут",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Администратор_username",
                table: "Администратор",
                column: "username",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Аэрапорт_Улица_id",
                table: "Аэрапорт",
                column: "Улица_id");

            migrationBuilder.CreateIndex(
                name: "IX_Город_Страна_id",
                table: "Город",
                column: "Страна_id");

            migrationBuilder.CreateIndex(
                name: "IX_Маршрут_Перевозчик_id",
                table: "Маршрут",
                column: "Перевозчик_id");

            migrationBuilder.CreateIndex(
                name: "IX_Маршрут_Расстояние_id",
                table: "Маршрут",
                column: "Расстояние_id");

            migrationBuilder.CreateIndex(
                name: "IX_Маршрут_Самолет_id",
                table: "Маршрут",
                column: "Самолет_id");

            migrationBuilder.CreateIndex(
                name: "IX_Расписание_Маршрут_id",
                table: "Расписание",
                column: "Маршрут_id");

            migrationBuilder.CreateIndex(
                name: "IX_Расстояние_Аэрапорт вылет_id",
                table: "Расстояние",
                column: "Аэрапорт вылет_id");

            migrationBuilder.CreateIndex(
                name: "IX_Расстояние_Аэрапорт прилет_id",
                table: "Расстояние",
                column: "Аэрапорт прилет_id");

            migrationBuilder.CreateIndex(
                name: "IX_Самолет_Производитель_id",
                table: "Самолет",
                column: "Производитель_id");

            migrationBuilder.CreateIndex(
                name: "IX_Самолет и перевозчик_Перевозчик_id",
                table: "Самолет и перевозчик",
                column: "Перевозчик_id");

            migrationBuilder.CreateIndex(
                name: "IX_Тариф_Класс_id",
                table: "Тариф",
                column: "Класс_id");

            migrationBuilder.CreateIndex(
                name: "IX_Тариф_Маршрут_id",
                table: "Тариф",
                column: "Маршрут_id");

            migrationBuilder.CreateIndex(
                name: "IX_Улица_Город_id",
                table: "Улица",
                column: "Город_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Администратор");

            migrationBuilder.DropTable(
                name: "Расписание");

            migrationBuilder.DropTable(
                name: "Самолет и перевозчик");

            migrationBuilder.DropTable(
                name: "Тариф");

            migrationBuilder.DropTable(
                name: "Класс");

            migrationBuilder.DropTable(
                name: "Маршрут");

            migrationBuilder.DropTable(
                name: "Перевозчик");

            migrationBuilder.DropTable(
                name: "Расстояние");

            migrationBuilder.DropTable(
                name: "Самолет");

            migrationBuilder.DropTable(
                name: "Аэрапорт");

            migrationBuilder.DropTable(
                name: "Производитель");

            migrationBuilder.DropTable(
                name: "Улица");

            migrationBuilder.DropTable(
                name: "Город");

            migrationBuilder.DropTable(
                name: "Страна");
        }
    }
}
