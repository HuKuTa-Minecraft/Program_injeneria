import { Paper, TextField, Button, Box, Typography } from "@mui/material";
import { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/axios";
import { AuthContext } from "../context/AuthContext";

export default function Login() {
  const [u, setU] = useState(""),
    [p, setP] = useState("");
  const { login } = useContext(AuthContext);
  const nav = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    try {
      await api.post("/auth/login", { username: u, password: p });
      login();
      nav("/");
    } catch {
      alert("Неверный логин или пароль");
    }
  };

  return (
    <Paper sx={{ maxWidth: 400, mx: "auto", mt: 8, p: 3 }}>
      <Typography variant="h5" align="center" mb={2}>
        Вход администратора
      </Typography>
      <Box
        component="form"
        onSubmit={submit}
        display="flex"
        flexDirection="column"
        gap={2}
      >
        <TextField
          label="Логин"
          value={u}
          onChange={(e) => setU(e.target.value)}
          required
        />
        <TextField
          label="Пароль"
          type="password"
          value={p}
          onChange={(e) => setP(e.target.value)}
          required
        />
        <Button type="submit" variant="contained">
          Войти
        </Button>
      </Box>
    </Paper>
  );
}
