using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AirTransportApi.Models;

[Table("Аэрапорт")]
public class Airport
{
    [Key]
    public int id { get; set; }

    [Column("Название")]
    public string Название { get; set; } = null!;

    [Column("Улица_id")]
    public int УлицаId { get; set; }
    public Street? Улица { get; set; }

    [InverseProperty(nameof(Distance.АэропортВылета))]
    public ICollection<Distance> Вылеты { get; set; } = new List<Distance>();

    [InverseProperty(nameof(Distance.АэропортПрилёта))]
    public ICollection<Distance> Прилёты { get; set; } = new List<Distance>();
}
