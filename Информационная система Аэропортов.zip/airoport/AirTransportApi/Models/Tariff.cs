using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AirTransportApi.Models;

[Table("Тариф")]
public class Tariff
{
    [Key]
    public int id { get; set; }

    [Column("Название")]
    public string Название { get; set; } = null!;

    [Column("Класс_id")]
    public int КлассId { get; set; }

    [Column("Маршрут_id")]
    public int RtId { get; set; }

    public FlightClass? Класс { get; set; }
    public Rt? Rt { get; set; }
}
