using AirTransportApi.Models;
using Microsoft.EntityFrameworkCore;

namespace AirTransportApi.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    /* ------------ DbSet'ы, которые нужны контроллёрам ------------- */
    public DbSet<Admin> Admins => Set<Admin>();
    public DbSet<Manufacturer> Manufacturers => Set<Manufacturer>();
    public DbSet<Carrier> Carriers => Set<Carrier>();
    public DbSet<Airplane> Airplanes => Set<Airplane>();
    public DbSet<AirplaneCarrier> AirplaneLinks => Set<AirplaneCarrier>();
    public DbSet<Country> Countries => Set<Country>();
    public DbSet<City> Cities => Set<City>();
    public DbSet<Street> Streets => Set<Street>();
    public DbSet<Airport> Airports => Set<Airport>();
    public DbSet<Distance> Distances => Set<Distance>();
    public DbSet<Rt> Rts => Set<Rt>();
    public DbSet<Schedule> Schedules => Set<Schedule>();
    public DbSet<FlightClass> FlightClasses => Set<FlightClass>();
    public DbSet<Tariff> Tariffs => Set<Tariff>();

    /* ------------ конфигурация (OnModelCreating) ------------------ */
    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<AirplaneCarrier>().HasKey(ac => new { ac.СамолетId, ac.ПеревозчикId });
        b.Entity<Distance>()
            .HasOne(d => d.АэропортВылета)
            .WithMany(a => a.Вылеты)
            .HasForeignKey(d => d.АэропортВылетаId)
            .OnDelete(DeleteBehavior.Restrict);
        b.Entity<Distance>()
            .HasOne(d => d.АэропортПрилёта)
            .WithMany(a => a.Прилёты)
            .HasForeignKey(d => d.АэропортПрилётаId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}
