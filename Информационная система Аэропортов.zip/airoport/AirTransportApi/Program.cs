using System.Text.Json.Serialization;
using AirTransportApi.Data;
using AirTransportApi.Filters;
using Microsoft.EntityFrameworkCore;

var allowedOrigin = "http://localhost:5173"; // адрес клиента

var builder = WebApplication.CreateBuilder(args);
var cfg = builder.Configuration;

builder.Services.AddCors(o =>
    o.AddPolicy(
        "spa",
        p => p.WithOrigins(allowedOrigin).AllowAnyHeader().AllowAnyMethod().AllowCredentials()
    )
);

/* ------------------ сервисы ------------------ */
builder.Services.AddDistributedMemoryCache();

// БД
builder.Services.AddDbContext<AppDbContext>(opt =>
    opt.UseNpgsql(cfg.GetConnectionString("Default"))
);

// MVC + лог-фильтр
builder
    .Services.AddControllers(o => o.Filters.Add<AdminActionLogger>())
    .AddJsonOptions(o =>
    {
        o.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
    });

// OpenAPI
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// сессии
builder.Services.AddSession(opt =>
{
    opt.IdleTimeout = TimeSpan.FromHours(6);
    opt.Cookie.HttpOnly = true;
    opt.Cookie.SameSite = SameSiteMode.Lax;
    opt.Cookie.SecurePolicy = CookieSecurePolicy.None;
});

var app = builder.Build();

/* ----------------- middleware ---------------- */
app.UseSwagger();
app.UseSwaggerUI();

app.UseCors("spa");
app.UseSession();
app.MapControllers();
app.Run();
