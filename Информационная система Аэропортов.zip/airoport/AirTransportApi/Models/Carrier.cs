using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AirTransportApi.Models;

[Table("Перевозчик")]
public class Carrier
{
    [Key]
    public int id { get; set; }

    [Column("Название")]
    public string Название { get; set; } = null!;

    public ICollection<Rt> Маршруты { get; set; } = new List<Rt>();
    public ICollection<AirplaneCarrier> Самолёты { get; set; } = new List<AirplaneCarrier>();
}
