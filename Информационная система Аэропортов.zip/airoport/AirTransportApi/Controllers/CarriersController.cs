using AirTransportApi.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AirTransportApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CarriersController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Get() => Ok(await db.Carriers.ToListAsync());

    [HttpGet("{id:int}/airplanes")]
    public async Task<IActionResult> GetAirplanes(int id)
    {
        var list = await db
            .AirplaneLinks.Where(l => l.ПеревозчикId == id)
            .Select(l => new { l.Самолет!.id, l.Самолет.Модель })
            .ToListAsync();
        return Ok(list);
    }
}
