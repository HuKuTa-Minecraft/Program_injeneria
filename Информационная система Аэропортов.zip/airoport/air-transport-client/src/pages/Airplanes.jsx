import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  Typography,
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { useEffect, useState, useContext } from "react";
import api from "../api/axios";
import { AuthContext } from "../context/AuthContext";

export default function Airplanes() {
  const { role } = useContext(AuthContext);

  const [rows, setRows] = useState([]);
  const [mans, setMans] = useState([]);
  const [open, setOpen] = useState(false);
  const [model, setModel] = useState("");
  const [speed, setSpeed] = useState(800);
  const [manId, setManId] = useState("");

  useEffect(() => {
    (async () => {
      setRows((await api.get("/airplanes")).data);
      setMans((await api.get("/manufacturers")).data);
    })();
  }, []);

  const refresh = async () => setRows((await api.get("/airplanes")).data);

  const add = async () => {
    await api.post("/airplanes", {
      модель: model,
      скоростьПолёта: speed,
      производительId: manId,
    });
    await refresh();
    setOpen(false);
  };

  const del = async (id) => {
    if (!confirm("Удалить?")) return;
    await api.delete(`/airplanes/${id}`);
    await refresh();
  };

  const cols = [
    { field: "id", headerName: "ID", width: 70 },
    { field: "модель", headerName: "Модель", flex: 1 },
    { field: "скоростьПолёта", headerName: "Скорость", width: 110 },
    { field: "производитель", headerName: "Производитель", flex: 1 },
    role === "Admin" && {
      field: "",
      width: 90,
      renderCell: (p) => (
        <Button color="error" onClick={() => del(p.row.id)}>
          X
        </Button>
      ),
    },
  ].filter(Boolean);

  return (
    <Box>
      <Typography variant="h4" mb={2}>
        Самолёты
      </Typography>
      {role === "Admin" && (
        <Button variant="contained" onClick={() => setOpen(true)}>
          Добавить
        </Button>
      )}
      <div style={{ height: 400, marginTop: 16 }}>
        <DataGrid rows={rows} columns={cols} disableRowSelectionOnClick />
      </div>

      {/* диалог добавления */}
      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogTitle>Новый самолёт</DialogTitle>
        <DialogContent
          sx={{ display: "flex", flexDirection: "column", gap: 2, mt: 1 }}
        >
          <TextField
            label="Модель"
            value={model}
            onChange={(e) => setModel(e.target.value)}
          />
          <TextField
            label="Скорость"
            type="number"
            value={speed}
            onChange={(e) => setSpeed(+e.target.value)}
          />
          <TextField
            select
            label="Производитель"
            value={manId}
            onChange={(e) => setManId(+e.target.value)}
          >
            {mans.map((m) => (
              <MenuItem key={m.id} value={m.id}>
                {m.название}
              </MenuItem>
            ))}
          </TextField>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Отмена</Button>
          <Button onClick={add} variant="contained">
            Сохранить
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
