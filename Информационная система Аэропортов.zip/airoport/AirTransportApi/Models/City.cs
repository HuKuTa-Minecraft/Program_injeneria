using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AirTransportApi.Models;

[Table("Город")]
public class City
{
    [Key]
    public int id { get; set; }

    [Column("Название")]
    public string Название { get; set; } = null!;

    [Column("Страна_id")]
    public int СтранаId { get; set; }
    public Country? Страна { get; set; }

    public ICollection<Street> Улицы { get; set; } = new List<Street>();
}
