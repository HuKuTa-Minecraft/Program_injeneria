using AirTransportApi.Data;
using AirTransportApi.Filters;
using AirTransportApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AirTransportApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RoutesController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var routes = await db
            .Rts.Include(r => r.Перевозчик)
            .Include(r => r.Самолет)
            .Include(r => r.Расстояние)
            .ThenInclude(d => d!.АэропортВылета)
            .Include(r => r.Расстояние)
            .ThenInclude(d => d!.АэропортПрилёта)
            .Select(r => new
            {
                r.id,
                Перевозчик = r.Перевозчик!.Название,
                Самолёт = r.Самолет!.Модель,
                АэропортВылета = r.Расстояние!.АэропортВылета!.Название,
                АэропортПрилёта = r.Расстояние.АэропортПрилёта!.Название,
            })
            .ToListAsync();

        return Ok(routes);
    }

    [HttpPost]
    [RequireAdmin]
    public async Task<IActionResult> Add([FromBody] Rt dto)
    {
        bool ok = await db.AirplaneLinks.AnyAsync(l =>
            l.СамолетId == dto.СамолетId && l.ПеревозчикId == dto.ПеревозчикId
        );
        if (!ok)
        {
            db.AirplaneLinks.Add(
                new AirplaneCarrier { СамолетId = dto.СамолетId, ПеревозчикId = dto.ПеревозчикId }
            );
        }
        db.Rts.Add(dto);
        await db.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { dto.id }, dto);
    }

    [HttpDelete("{id:int}")]
    [RequireAdmin]
    public async Task<IActionResult> Delete(int id)
    {
        var rt = await db.Rts.FindAsync(id);
        if (rt is null)
            return NotFound();
        var schedule = await db.Schedules.Where(s => s.RtId == id).ToListAsync();
        if (schedule.Any())
            db.Schedules.RemoveRange(schedule);
        var tariffs = await db.Tariffs.Where(t => t.RtId == id).ToListAsync();
        if (tariffs.Any())
            db.Tariffs.RemoveRange(tariffs);
        db.Rts.Remove(rt);
        await db.SaveChangesAsync();
        return NoContent();
    }
}
