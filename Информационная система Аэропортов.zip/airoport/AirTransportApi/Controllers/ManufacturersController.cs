using AirTransportApi.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AirTransportApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ManufacturersController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Get() => Ok(await db.Manufacturers.ToListAsync());
}
