using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AirTransportApi.Models;

[Table("Самолет и перевозчик")]
public class AirplaneCarrier
{
    [Column("Самолет_id")]
    public int СамолетId { get; set; }

    [Column("Перевозчик_id")]
    public int ПеревозчикId { get; set; }

    public Airplane? Самолет { get; set; }
    public Carrier? Перевозчик { get; set; }
}
