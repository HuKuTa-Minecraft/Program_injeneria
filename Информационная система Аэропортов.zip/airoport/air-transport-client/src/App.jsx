import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import Layout from "./components/Layout";
import ProtectedRoute from "./components/ProtectedRoute";

import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Airplanes from "./pages/Airplanes";
import Passengers from "./pages/Passengers";
import RoutesPage from "./pages/Routes";
import SchedulePage from "./pages/Schedule";
import Contacts from "./pages/Contacts";

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route index element={<Home />} />
            <Route path="airplanes" element={<Airplanes />} />
            <Route path="passengers" element={<Passengers />} />
            <Route path="routes" element={<RoutesPage />} />
            <Route path="schedules" element={<SchedulePage />} />
            <Route path="contacts" element={<Contacts />} />
            <Route path="login" element={<Login />} />
            <Route
              path="register"
              element={
                <ProtectedRoute>
                  <Register />
                </ProtectedRoute>
              }
            />
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
