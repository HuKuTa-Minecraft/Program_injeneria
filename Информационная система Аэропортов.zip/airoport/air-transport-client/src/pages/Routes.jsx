import {
  Box,
  Typography,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Autocomplete,
  TextField,
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { useEffect, useState, useContext } from "react";
import api from "../api/axios";
import { AuthContext } from "../context/AuthContext";

export default function Routes() {
  const { role } = useContext(AuthContext);

  /* --- таблица маршрутов --- */
  const [rows, setRows] = useState([]);
  const loadRoutes = async () => setRows((await api.get("/routes")).data);

  /* --- каталоги для combobox --- */
  const [carriers, setCarriers] = useState([]);
  const [airplanes, setAirplanes] = useState([]);
  const [distances, setDistances] = useState([]);

  /* --- состояние формы --- */
  const empty = { carrier: null, airplane: null, distance: null };
  const [form, setForm] = useState(empty);
  const [open, setOpen] = useState(false);

  /* загрузка справочников один раз */
  useEffect(() => {
    loadRoutes();
    (async () => {
      setCarriers((await api.get("/carriers")).data);
      setDistances((await api.get("/distances")).data);
    })();
  }, []);

  /* загрузка самолётов при выборе перевозчика */
  const onCarrierChange = async (_e, value) => {
    setForm({ ...form, carrier: value, airplane: null });
    if (value)
      setAirplanes((await api.get(`/carriers/${value.id}/airplanes`)).data);
    else setAirplanes([]);
  };

  /* ---- CRUD ---- */
  const add = async () => {
    if (!form.carrier || !form.airplane || !form.distance) return;

    try {
      await api.post("/routes", {
        ПеревозчикId: form.carrier.id,
        СамолетId: form.airplane.id,
        РасстояниеId: form.distance.id,
      });
      await loadRoutes();
      setOpen(false);
      setForm(empty);
    } catch (err) {
      alert(err.response?.data ?? "Не удалось добавить маршрут");
    }
  };

  const del = async (id) => {
    if (!confirm("Удалить маршрут?")) return;
    try {
      await api.delete(`/routes/${id}`);
      await loadRoutes();
    } catch (err) {
      alert(err.response?.data ?? "Ошибка удаления");
    }
  };

  /* ---- колонки таблицы ---- */
  const cols = [
    { field: "id", headerName: "ID", width: 70 },
    { field: "перевозчик", headerName: "Перевозчик", flex: 1 },
    { field: "самолёт", headerName: "Самолёт", flex: 1 },
    { field: "аэропортВылета", headerName: "Откуда", flex: 1 },
    { field: "аэропортПрилёта", headerName: "Куда", flex: 1 },
    role === "Admin" && {
      field: "",
      width: 90,
      renderCell: (p) => (
        <Button color="error" onClick={() => del(p.row.id)}>
          X
        </Button>
      ),
    },
  ].filter(Boolean);

  return (
    <Box>
      <Typography variant="h4" mb={2}>
        Маршруты
      </Typography>

      {role === "Admin" && (
        <Button variant="contained" onClick={() => setOpen(true)}>
          Добавить
        </Button>
      )}

      <div style={{ height: 430, marginTop: 16 }}>
        <DataGrid rows={rows} columns={cols} disableRowSelectionOnClick />
      </div>

      {/* ------ диалог добавления ------ */}
      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Новый маршрут</DialogTitle>
        <DialogContent
          sx={{ display: "flex", flexDirection: "column", gap: 3, mt: 1 }}
        >
          <Autocomplete
            options={carriers}
            getOptionLabel={(o) => o.название || ""}
            value={form.carrier}
            onChange={onCarrierChange}
            renderInput={(p) => <TextField {...p} label="Перевозчик" />}
          />

          <Autocomplete
            options={airplanes}
            getOptionLabel={(o) => o.модель || ""}
            value={form.airplane}
            onChange={(_e, v) => setForm({ ...form, airplane: v })}
            disabled={!form.carrier}
            renderInput={(p) => <TextField {...p} label="Самолёт" />}
          />

          <Autocomplete
            options={distances}
            getOptionLabel={(o) => `${o.аэропортВылета} → ${o.аэропортПрилёта}`}
            value={form.distance}
            onChange={(_e, v) => setForm({ ...form, distance: v })}
            renderInput={(p) => (
              <TextField {...p} label="Маршрут (расстояние)" />
            )}
          />
        </DialogContent>

        <DialogActions>
          <Button onClick={() => setOpen(false)}>Отмена</Button>
          <Button variant="contained" onClick={add} disabled={!form.airplane}>
            Сохранить
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
